from main import end_player_score
from main import prev_highscore

prev_highscore = 0

class highscore():
    def __init__():
        if end_player_score > prev_highscore:
            prev_highscore = end_player_score
            highscore_text = font.render('highscore: '+str(prev_highscore), True, (255, 255, 255))
